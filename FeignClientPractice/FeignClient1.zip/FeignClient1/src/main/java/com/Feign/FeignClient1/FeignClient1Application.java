package com.Feign.FeignClient1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeignClient1Application {

	public static void main(String[] args) {
		SpringApplication.run(FeignClient1Application.class, args);
	}

}
