package com.Feign.FeignClient1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeignClient1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
