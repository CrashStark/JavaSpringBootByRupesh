package com.Practice.PracticeQuestion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticeQuestionApplicationTests {

	@Test
	void contextLoads() {
	}

}
