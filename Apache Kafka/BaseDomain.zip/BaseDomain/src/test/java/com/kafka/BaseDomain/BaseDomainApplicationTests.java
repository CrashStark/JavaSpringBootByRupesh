package com.kafka.BaseDomain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaseDomainApplicationTests {

	@Test
	void contextLoads() {
	}

}
