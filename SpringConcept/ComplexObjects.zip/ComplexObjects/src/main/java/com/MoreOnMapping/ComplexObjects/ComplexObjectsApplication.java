package com.MoreOnMapping.ComplexObjects;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComplexObjectsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComplexObjectsApplication.class, args);
	}

}
