package com.MoreOnMapping.ComplexObjects;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComplexObjectsApplicationTests {

	@Test
	void contextLoads() {
	}

}
