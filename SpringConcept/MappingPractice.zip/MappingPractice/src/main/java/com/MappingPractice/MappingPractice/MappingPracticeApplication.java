package com.MappingPractice.MappingPractice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MappingPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MappingPracticeApplication.class, args);
	}

}
