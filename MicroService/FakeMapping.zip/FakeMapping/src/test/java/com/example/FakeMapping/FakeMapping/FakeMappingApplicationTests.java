package com.example.FakeMapping.FakeMapping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FakeMappingApplicationTests {

	@Test
	void contextLoads() {
	}

}
