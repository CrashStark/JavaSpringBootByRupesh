package com.example.Appointment.Appointement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppointementApplicationTests {

	@Test
	void contextLoads() {
	}

}
