package com.example.Doctor.DoctorModuleMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoctorModuleMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
