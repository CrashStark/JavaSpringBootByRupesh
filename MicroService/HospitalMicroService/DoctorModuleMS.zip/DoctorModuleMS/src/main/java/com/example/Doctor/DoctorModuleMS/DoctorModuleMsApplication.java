package com.example.Doctor.DoctorModuleMS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoctorModuleMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoctorModuleMsApplication.class, args);
	}

}
