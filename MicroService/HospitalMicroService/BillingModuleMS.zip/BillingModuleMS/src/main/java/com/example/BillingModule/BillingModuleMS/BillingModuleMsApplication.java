package com.example.BillingModule.BillingModuleMS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BillingModuleMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(BillingModuleMsApplication.class, args);
	}

}
